const express = require('express');
const router = express.Router();
const Product = require('../models/Product');
const auth = require('../middleware/auth');

// Public: List products
router.get('/', async (req, res) => {
  try {
    const products = await Product.find().limit(50);
    res.json(products);
  } catch (err) {
    res.status(500).json({ msg: 'Error al obtener productos' });
  }
});

// Manager only: Create product
router.post('/', auth, async (req, res) => {
  try {
    if (req.user.role !== 'manager') return res.status(403).json({ msg: 'forbidden' });
    const product = await Product.create(req.body);
    res.json(product);
  } catch (err) {
    res.status(500).json({ msg: 'Error al crear producto' });
  }
});

// Manager only: Update quantity
router.patch('/:id', auth, async (req, res) => {
  try {
    if (req.user.role !== 'manager') return res.status(403).json({ msg: 'forbidden' });
    const updated = await Product.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!updated) return res.status(404).json({ msg: 'Producto no encontrado' });
    res.json(updated);
  } catch (err) {
    res.status(500).json({ msg: 'Error al actualizar producto' });
  }
});

module.exports = router;
